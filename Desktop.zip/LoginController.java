package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.skin.ButtonSkin;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class LoginController implements Initializable {
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	
	}
	
	  	public static LoginController instance;
	  	
	  	public LoginController() {
	  		instance = this;
	  	}
	  	
	  	public static LoginController getinstance() {
	  		return instance;
	  	}
	  	
	  	ArrayList<Button> buttons = new ArrayList<>();
	  	
	  	
	  	@FXML
	    private BorderPane borderpane;

	    @FXML
	    private Button btnlogin;

	    @FXML
	    private Button btnpc_i;

	    @FXML
	    private Button btnpc_10;

	    @FXML
	    private Button btnpc_11;

	    @FXML
	    private Button btnpc_12;

	    @FXML
	    private Button btnpc_13;

	    @FXML
	    private Button btnpc_14;

	    @FXML
	    private Button btnpc_15;

	    @FXML
	    private Button btnpc_16;

	    @FXML
	    private Button btnpc_17;

	    @FXML
	    private Button btnpc_18;

	    @FXML
	    private Button btnpc_19;

	    @FXML
	    private Button btnpc_2;

	    @FXML
	    private Button btnpc_20;

	    @FXML
	    private Button btnpc_3;

	    @FXML
	    private Button btnpc_4;

	    @FXML
	    private Button btnpc_5;

	    @FXML
	    private Button btnpc_6;

	    @FXML
	    private Button btnpc_7;

	    @FXML
	    private Button btnpc_8;

	    @FXML
	    private Button btnpc_9;

	    @FXML
	    private Label lblid_1;

	    @FXML
	    private Label lblid_10;

	    @FXML
	    private Label lblid_11;

	    @FXML
	    private Label lblid_12;

	    @FXML
	    private Label lblid_13;

	    @FXML
	    private Label lblid_14;

	    @FXML
	    private Label lblid_15;

	    @FXML
	    private Label lblid_16;

	    @FXML
	    private Label lblid_17;

	    @FXML
	    private Label lblid_18;

	    @FXML
	    private Label lblid_19;

	    @FXML
	    private Label lblid_2;

	    @FXML
	    private Label lblid_20;

	    @FXML
	    private Label lblid_3;

	    @FXML
	    private Label lblid_4;

	    @FXML
	    private Label lblid_5;

	    @FXML
	    private Label lblid_6;

	    @FXML
	    private Label lblid_7;

	    @FXML
	    private Label lblid_8;

	    @FXML
	    private Label lblid_9;

	    @FXML
	    private Label lbltimeremaining_1;

	    @FXML
	    private Label lbltimeremaining_10;

	    @FXML
	    private Label lbltimeremaining_11;

	    @FXML
	    private Label lbltimeremaining_12;

	    @FXML
	    private Label lbltimeremaining_13;

	    @FXML
	    private Label lbltimeremaining_14;

	    @FXML
	    private Label lbltimeremaining_15;

	    @FXML
	    private Label lbltimeremaining_16;

	    @FXML
	    private Label lbltimeremaining_17;

	    @FXML
	    private Label lbltimeremaining_18;

	    @FXML
	    private Label lbltimeremaining_19;

	    @FXML
	    private Label lbltimeremaining_2;

	    @FXML
	    private Label lbltimeremaining_20;

	    @FXML
	    private Label lbltimeremaining_3;

	    @FXML
	    private Label lbltimeremaining_4;

	    @FXML
	    private Label lbltimeremaining_5;

	    @FXML
	    private Label lbltimeremaining_6;

	    @FXML
	    private Label lbltimeremaining_7;

	    @FXML
	    private Label lbltimeremaining_8;

	    @FXML
	    private Label lbltimeremaining_9;

	    @FXML
	    private AnchorPane loginanchor;

	    @FXML
	    private TextField txtid;

	    @FXML
	    private PasswordField txtpassword;

	    @FXML
	    void login(ActionEvent event) {
	    	loadpage("k_main");
	    }
	    
	    public void loadpage( String page ) {
	    	try {
	    		Parent parent = FXMLLoader.load(
	    				getClass().getResource("/fxml/"+page+".fxml"));
	    		borderpane.setCenter(parent);
	    	}
	    	catch (Exception e) {}
	    }
}

package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class MainController {


    @FXML
    private Button btncancel;
    @FXML
    private Button btnpayment;
    @FXML
    private Button btnpc_1;
    @FXML
    private Button btnpc_10;
    @FXML
    private Button btnpc_11;
    @FXML
    private Button btnpc_12;
    @FXML
    private Button btnpc_13;
    @FXML
    private Button btnpc_14;
    @FXML
    private Button btnpc_15;
    @FXML
    private Button btnpc_16;
    @FXML
    private Button btnpc_17;
    @FXML
    private Button btnpc_18;
    @FXML
    private Button btnpc_19;
    @FXML
    private Button btnpc_2;
    @FXML
    private Button btnpc_20;
    @FXML
    private Button btnpc_3;
    @FXML
    private Button btnpc_4;
    @FXML
    private Button btnpc_5;
    @FXML
    private Button btnpc_6;
    @FXML
    private Button btnpc_7;
    @FXML
    private Button btnpc_8;
    @FXML
    private Button btnpc_9;
    @FXML
    private Button btnprice_1000;
    @FXML
    private Button btnprice_2000;
    @FXML
    private Button btnprice_3000;
    @FXML
    private Button btnprice_5000;
    @FXML
    private Label lblid_1;
    @FXML
    private Label lblid_10;
    @FXML
    private Label lblid_11;
    @FXML
    private Label lblid_12;
    @FXML
    private Label lblid_13;
    @FXML
    private Label lblid_14;
    @FXML
    private Label lblid_15;
    @FXML
    private Label lblid_16;
    @FXML
    private Label lblid_17;
    @FXML
    private Label lblid_18;
    @FXML
    private Label lblid_19;
    @FXML
    private Label lblid_2;
    @FXML
    private Label lblid_20;
    @FXML
    private Label lblid_3;
    @FXML
    private Label lblid_4;
    @FXML
    private Label lblid_5;
    @FXML
    private Label lblid_6;
    @FXML
    private Label lblid_7;
    @FXML
    private Label lblid_8;
    @FXML
    private Label lblid_9;
    @FXML
    private Label lbltimeremaining_1;
    @FXML
    private Label lbltimeremaining_10;
    @FXML
    private Label lbltimeremaining_11;
    @FXML
    private Label lbltimeremaining_12;
    @FXML
    private Label lbltimeremaining_13;
    @FXML
    private Label lbltimeremaining_14;
    @FXML
    private Label lbltimeremaining_15;
    @FXML
    private Label lbltimeremaining_16;
    @FXML
    private Label lbltimeremaining_17;
    @FXML
    private Label lbltimeremaining_18;
    @FXML
    private Label lbltimeremaining_19;
    @FXML
    private Label lbltimeremaining_2;
    @FXML
    private Label lbltimeremaining_20;
    @FXML
    private Label lbltimeremaining_3;
    @FXML
    private Label lbltimeremaining_4;
    @FXML
    private Label lbltimeremaining_5;
    @FXML
    private Label lbltimeremaining_6;
    @FXML
    private Label lbltimeremaining_7;
    @FXML
    private Label lbltimeremaining_8;
    @FXML
    private Label lbltimeremaining_9;
    @FXML
    void cancel(ActionEvent event) {
    	LoginController.getinstance().loadpage("k_login");
    }

    @FXML
    void payment(ActionEvent event) {

    }

    @FXML
    void pc_1(ActionEvent event) {

    }

    @FXML
    void pc_10(ActionEvent event) {

    }

    @FXML
    void pc_11(ActionEvent event) {

    }

    @FXML
    void pc_12(ActionEvent event) {

    }

    @FXML
    void pc_13(ActionEvent event) {

    }

    @FXML
    void pc_14(ActionEvent event) {

    }

    @FXML
    void pc_15(ActionEvent event) {

    }

    @FXML
    void pc_16(ActionEvent event) {

    }

    @FXML
    void pc_17(ActionEvent event) {

    }

    @FXML
    void pc_18(ActionEvent event) {

    }

    @FXML
    void pc_19(ActionEvent event) {

    }

    @FXML
    void pc_2(ActionEvent event) {

    }

    @FXML
    void pc_20(ActionEvent event) {

    }

    @FXML
    void pc_3(ActionEvent event) {

    }

    @FXML
    void pc_4(ActionEvent event) {

    }

    @FXML
    void pc_5(ActionEvent event) {

    }

    @FXML
    void pc_6(ActionEvent event) {

    }

    @FXML
    void pc_7(ActionEvent event) {

    }

    @FXML
    void pc_8(ActionEvent event) {

    }

    @FXML
    void pc_9(ActionEvent event) {

    }

    @FXML
    void price_1000(ActionEvent event) {

    }

    @FXML
    void price_2000(ActionEvent event) {

    }

    @FXML
    void price_3000(ActionEvent event) {

    }

    @FXML
    void price_5000(ActionEvent event) {

    }
}

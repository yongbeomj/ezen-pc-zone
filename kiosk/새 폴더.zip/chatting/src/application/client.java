package application;

import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Scanner;

public class client {

	
	public static void main(String[] args) {
		
		Socket socket =new Socket();
		try {
			while(true) {
				socket.connect(new InetSocketAddress("127.168.102.51", 5000));
				System.out.println("���� ���� ����");
				Scanner scanner = new Scanner(System.in);
				System.out.println("�޼��� �Է�");
				String msg = scanner.nextLine();
				OutputStream outputStream = socket.getOutputStream(); //���� ��� ��Ʈ��
				System.out.println(msg);
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}

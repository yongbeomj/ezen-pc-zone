package application;

public class Snippet {
	InputStream inputStream = socket.getInputStream(); // 소켓 입력 스트림 
					byte[] bytes = new byte[1000];	// 바이트열 배열 선언 
					inputStream.read( bytes );		// 소켓 입력스트림에서 입력받은 바이트를 배열 저장 
					System.out.println(" 클라이언트의 메시지 : " + new String(bytes) ); // 바이트배열 -> 문자열 변환
}


package Dao;

public class TimeDao {

}

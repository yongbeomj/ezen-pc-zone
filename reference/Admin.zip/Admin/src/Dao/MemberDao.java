package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Domain.Member;
import Domain.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class MemberDao {
	private Connection connection; 
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	
	private static MemberDao memberDao = new MemberDao();
	
	
	public MemberDao() {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/ezenpczone?serverTimeZonse=UTC", "root",
					"1234");
		} catch (Exception e) {
			System.err.println(" *DB���� ���� : " + e);
		}
	}
	
	public static MemberDao getMemberDao() {
		return memberDao;
	}
	
	
	public ObservableList<Member> memberlist() {
		// 1. ����Ʈ ����
		ObservableList<Member> members = FXCollections.observableArrayList();
		String sql = "select * from member order by m_no desc";
		
		try {
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				
				Member member = new Member(resultSet.getInt(1),
						resultSet.getString(2),
						resultSet.getString(3), 
						resultSet.getString(4),
						resultSet.getString(5),
						resultSet.getString(6), 
						resultSet.getInt(7));

			
				// ��ü ����Ʈ ����
				
				members.add(member);
			}
		return members;
		} catch (Exception e) {
			System.out.println("ddd");
		}
		return members;
		
	}
	
	
	public boolean update(Member member) {
		String sql = "update member set m_pw=?, m_name=?, m_email=?, m_phone=?, m_sex=? where m_no=?" ;
		
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, member.getM_pw());
			preparedStatement.setString(2, member.getM_name());
			preparedStatement.setString(3, member.getM_email());
			preparedStatement.setString(4, member.getM_phone());
			preparedStatement.setInt(5, member.getM_sex());
			preparedStatement.setInt(6, member.getM_no());
			preparedStatement.executeUpdate();
			
			return true;
		} catch (Exception e) {	
		}
		return false;
	}
	
	

	
	
	public boolean delete(int m_no) {
		String sql = "delete from member where m_no=?";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, m_no);
			preparedStatement.executeUpdate();
			return true;
		} catch (Exception e) {
		}
		return false;
		
	}
	
	
	
	
	
			
	
	
	
	
	

}

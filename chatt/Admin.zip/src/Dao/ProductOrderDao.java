package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Domain.Product;
import Domain.ProductOrder;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ProductOrderDao {
	
	private Connection connection;
	private PreparedStatement preparedStatement; 
	private ResultSet resultSet; 
	
	
	public ProductOrderDao() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ezenpczone?serverTimeZonse=UTC", "root",
					"1234");
		} catch (Exception e) {
			System.err.println(" *DB���� ���� : " + e);
		}
	}
	
	private static ProductOrderDao productorderDao = new ProductOrderDao();
	
	public static ProductOrderDao getProductOrderDao() {
		return productorderDao;
	}
	
	
	
	public ObservableList<ProductOrder> productorderlist() {
		ObservableList<ProductOrder> productorders = FXCollections.observableArrayList();
		String sql = "select * from productorder order by p_no desc";
		
		try {
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				ProductOrder productorder = new ProductOrder( 
						resultSet.getInt(1),
						resultSet.getInt(2), 
						resultSet.getString(3), 
						resultSet.getString(4), 
						resultSet.getInt(5), 
						resultSet.getInt(6), 
						resultSet.getString(7),
						resultSet.getInt(8));
			
				// ��ü ����Ʈ ����
				productorders.add(productorder);
			}
		return productorders;
		} catch (Exception e) {
		}
		return productorders;
		
	}
}

package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import domain.Productorder;

public class ProductorderDao {

	
	private Connection connection; // db ���� �������̽� ����
	private PreparedStatement preparedStatement; // sql ���� �������̽� ����
	private ResultSet resultSet; // ���� ���� �������̽� ����

	public ProductorderDao() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ezenpczone?serverTimezone=UTC",
					"root", "1234");
		} catch (Exception e) {
		}
	}
	
	private static ProductorderDao proDao = new ProductorderDao();
	
	public static ProductorderDao getProductDao () {
		return proDao;
	}
	
	public boolean productorder(Productorder order) {
		String sql = "insert into productorder(po_contents,po_count,"
				+ "pc_no ,m_id ,po_price,po_activation) value(?,?,?,?,?,?)";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, order.getPo_contents());
			preparedStatement.setInt(2, order.getPo_count());
			preparedStatement.setInt(3, order.getPc_no());
			preparedStatement.setString(4,order.getM_id());
			preparedStatement.setInt(5, order.getPo_price());
			preparedStatement.setInt(6, order.getPo_activation());
			preparedStatement.executeUpdate();
			return true;
			
		}catch (Exception e) {
			System.out.println("db����? db�� �����");
			return false;
		}
	}
}

package dao;

import javafx.scene.control.Button;

public class ��ư {

	//select p_no ,p_name,p_img, p_count ,p_category,p_price,p_activation  
	public Button button = new Button();
	public int p_no ;
	public String p_name;
	public String p_img;
	public int p_count;
	public String p_category;
	public int p_price;
	public int p_activation;
	public int sale_count;
	
}

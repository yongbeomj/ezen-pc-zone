package Controller;

import javafx.fxml.FXML;
import javafx.scene.control.TableView;

public class ProductOrderController   {
    @FXML
    private TableView<?> txtorderdetail;

	
}

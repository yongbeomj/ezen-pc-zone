package Controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class SystemController{

	// ��üȭ
	public static SystemController instance;
	public SystemController() {
		instance = this;
	}
	public static SystemController getinstance() {
		return instance;
	}
	
	
	
	
	// �ε������� 
	public void loadpage(String page) {
		try {
			Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
			mainpane.setCenter(parent);
		} catch (Exception e) {
		}

	}

	@FXML
	private Button btnchatting;

	@FXML
	private Button btnmember;

	@FXML
	private Button btnproduct;

	@FXML
	private Button btnsales;

	@FXML
	private BorderPane mainpane;

	// ä�ð��� ���
	@FXML
	void chatting(ActionEvent event) {
		Stage stage = new Stage();
		try {
			Parent parent = FXMLLoader.load(getClass().getResource("/fxml/c_chatting.fxml"));

			Scene scene = new Scene(parent);
			stage.setScene(scene);
			stage.setResizable(false);
			stage.show();
		} catch (Exception e) {
		}
	}
	
	// ȸ������ ���
	@FXML
	void member(ActionEvent event) {
		loadpage("a_member");
	}
	
	// ��ǰ���� ���
	@FXML
	void product(ActionEvent event) {
		loadpage("a_productlist");
	}
	
	// ������� ���
	@FXML
	void sales(ActionEvent event) {

		loadpage("a_sales");
	}
	
	
	
	
	
}

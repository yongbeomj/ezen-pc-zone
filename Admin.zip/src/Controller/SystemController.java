package Controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class SystemController implements Initializable{

	//�߰�
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		Button[] pcbuttons = {  null, btnpc_1 ,btnpc_2 ,btnpc_3 ,btnpc_4 ,btnpc_5 ,btnpc_6 ,btnpc_7 ,btnpc_8 ,btnpc_9 ,btnpc_10 
				,btnpc_11  ,btnpc_12  ,btnpc_13,btnpc_14,btnpc_15,btnpc_16,btnpc_17,btnpc_18,btnpc_19,btnpc_20};
		
		Label[] pcids = { null,lblid_1,lblid_2,lblid_3,lblid_4,lblid_5,lblid_6,lblid_7,lblid_8,lblid_9,lblid_10
				,lblid_11,lblid_12,lblid_13,lblid_14,lblid_15,lblid_16,lblid_17,lblid_18,lblid_19,lblid_20};
		
		Label[] lbltimes = { null,lbltimeremaining_1,lbltimeremaining_2,lbltimeremaining_3,lbltimeremaining_4,lbltimeremaining_5,lbltimeremaining_6,lbltimeremaining_7
				,lbltimeremaining_8,lbltimeremaining_9,lbltimeremaining_10,lbltimeremaining_11,lbltimeremaining_12,lbltimeremaining_13,lbltimeremaining_14,lbltimeremaining_15
				,lbltimeremaining_16,lbltimeremaining_17,lbltimeremaining_18,lbltimeremaining_19,lbltimeremaining_20};
		
		
	}
	
	// ��üȭ
	public static SystemController instance;
	public SystemController() {
		instance = this;
	}
	public static SystemController getinstance() {
		return instance;
	}
	
	
	
	
	// �ε������� 
	public void loadpage(String page) {
		try {
			Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
			mainpane.setCenter(parent);
		} catch (Exception e) {
		}

	}

	@FXML
    private Button btnchatting;

    @FXML
    private Button btnmember;

    @FXML
    private Button btnpc_1;

    @FXML
    private Button btnpc_10;

    @FXML
    private Button btnpc_11;

    @FXML
    private Button btnpc_12;

    @FXML
    private Button btnpc_13;

    @FXML
    private Button btnpc_14;

    @FXML
    private Button btnpc_15;

    @FXML
    private Button btnpc_16;

    @FXML
    private Button btnpc_17;

    @FXML
    private Button btnpc_18;

    @FXML
    private Button btnpc_19;

    @FXML
    private Button btnpc_2;

    @FXML
    private Button btnpc_20;

    @FXML
    private Button btnpc_3;

    @FXML
    private Button btnpc_4;

    @FXML
    private Button btnpc_5;

    @FXML
    private Button btnpc_6;

    @FXML
    private Button btnpc_7;

    @FXML
    private Button btnpc_8;

    @FXML
    private Button btnpc_9;

    @FXML
    private Button btnproduct;

    @FXML
    private Button btnsales;

    @FXML
    private Label lblid_1;

    @FXML
    private Label lblid_10;

    @FXML
    private Label lblid_11;

    @FXML
    private Label lblid_12;

    @FXML
    private Label lblid_13;

    @FXML
    private Label lblid_14;

    @FXML
    private Label lblid_15;

    @FXML
    private Label lblid_16;

    @FXML
    private Label lblid_17;

    @FXML
    private Label lblid_18;

    @FXML
    private Label lblid_19;

    @FXML
    private Label lblid_2;

    @FXML
    private Label lblid_20;

    @FXML
    private Label lblid_3;

    @FXML
    private Label lblid_4;

    @FXML
    private Label lblid_5;

    @FXML
    private Label lblid_6;

    @FXML
    private Label lblid_7;

    @FXML
    private Label lblid_8;

    @FXML
    private Label lblid_9;

    @FXML
    private Label lbltimeremaining_1;

    @FXML
    private Label lbltimeremaining_10;

    @FXML
    private Label lbltimeremaining_11;

    @FXML
    private Label lbltimeremaining_12;

    @FXML
    private Label lbltimeremaining_13;

    @FXML
    private Label lbltimeremaining_14;

    @FXML
    private Label lbltimeremaining_15;

    @FXML
    private Label lbltimeremaining_16;

    @FXML
    private Label lbltimeremaining_17;

    @FXML
    private Label lbltimeremaining_18;

    @FXML
    private Label lbltimeremaining_19;

    @FXML
    private Label lbltimeremaining_2;

    @FXML
    private Label lbltimeremaining_20;

    @FXML
    private Label lbltimeremaining_3;

    @FXML
    private Label lbltimeremaining_4;

    @FXML
    private Label lbltimeremaining_5;

    @FXML
    private Label lbltimeremaining_6;

    @FXML
    private Label lbltimeremaining_7;

    @FXML
    private Label lbltimeremaining_8;

    @FXML
    private Label lbltimeremaining_9;

    @FXML
    private BorderPane mainpane;

    @FXML
    void chatting(ActionEvent event) {
    	Stage stage = new Stage();
		try {
			Parent parent = FXMLLoader.load(getClass().getResource("/fxml/c_chatting.fxml"));

			Scene scene = new Scene(parent);
			stage.setScene(scene);
			stage.setResizable(false);
			stage.show();
		} catch (Exception e) {
		}
    }

    @FXML
    void member(ActionEvent event) {
    	loadpage("a_member");
    }

    @FXML
    void pc_1(ActionEvent event) {

    }

    @FXML
    void pc_10(ActionEvent event) {

    }

    @FXML
    void pc_11(ActionEvent event) {

    }

    @FXML
    void pc_12(ActionEvent event) {

    }

    @FXML
    void pc_13(ActionEvent event) {

    }

    @FXML
    void pc_14(ActionEvent event) {

    }

    @FXML
    void pc_15(ActionEvent event) {

    }

    @FXML
    void pc_16(ActionEvent event) {

    }

    @FXML
    void pc_17(ActionEvent event) {

    }

    @FXML
    void pc_18(ActionEvent event) {

    }

    @FXML
    void pc_19(ActionEvent event) {

    }

    @FXML
    void pc_2(ActionEvent event) {

    }

    @FXML
    void pc_20(ActionEvent event) {

    }

    @FXML
    void pc_3(ActionEvent event) {

    }

    @FXML
    void pc_4(ActionEvent event) {

    }

    @FXML
    void pc_5(ActionEvent event) {

    }

    @FXML
    void pc_6(ActionEvent event) {

    }

    @FXML
    void pc_7(ActionEvent event) {

    }

    @FXML
    void pc_8(ActionEvent event) {

    }

    @FXML
    void pc_9(ActionEvent event) {

    }

    @FXML
    void product(ActionEvent event) {
    	loadpage("a_productlist");
    }

    @FXML
    void sales(ActionEvent event) {
    	loadpage("a_sales");
    }
	
	
	
	
	
}

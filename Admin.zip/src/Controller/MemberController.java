package Controller;

import Dao.ProductDao;
import Domain.Member;
import Domain.Product;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class MemberController {

	@FXML
	private Button btnback;

	@FXML
	private Button btndelete;

	@FXML
	private Button btnserch;

	@FXML
	private Button btnupdate;

	@FXML
	private TableView<?> memberlist;

	@FXML
	private TextField serch;

	@FXML
	private TextField txtmemail;

	@FXML
	private TextField txtmname;

	@FXML
	private TextField txtmphone;

	@FXML
	private TextField txtmpw;

	@FXML
	private TextField txtmsex;

	@FXML
	void delete(ActionEvent event) {

	}

	@FXML
	void update(ActionEvent event) {
		String mname = txtmname.getText();
		String mpw = txtmpw.getText();
		String memail = txtmemail.getText();
		String mphone = txtmphone.getText();
		String msex = txtmsex.getText();
	
		// ��üȭ
		Member member2 = new Member(
				.getM_no(), 
				mid,
				mpw,
				mname,
				memail,
				mphone,
				msex);
		
		// DB �ֱ�
		boolean result = ProductDao.getProductDao().update(member2);
		if(result) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setHeaderText("ȸ�� ���� �Ϸ�");
			alert.showAndWait();
			SystemController.getinstance().loadpage("a_member");
	
		}
	}
	
	@FXML
	void back(ActionEvent event) {
		SystemController.getinstance().loadpage("a_system");
	}

}

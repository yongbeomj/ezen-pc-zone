package Controller;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Optional;
import java.util.ResourceBundle;

import Dao.MemberDao;
import Dao.ProductDao;
import Domain.Member;
import Domain.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseButton;

public class MemberController implements Initializable {

	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;

	private static Member member = new Member();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		membertableload();

	}

	@FXML
	private Label lblemail;

	@FXML
	private Label lblname;

	@FXML
	private Label lblphone;

	@FXML
	private Label lblpw;

	@FXML
	private Label lblsex;

	@FXML
	private Button btnback;

	@FXML
	private Button btndelete;


	@FXML
	private Button btnupdate;

	@FXML
	private TableView<Member> memberlist;

	@FXML
	private TextField txtmemail;

	@FXML
	private TextField txtmname;

	@FXML
	private TextField txtmphone;

	@FXML
	private TextField txtmpw;

	@FXML
	private TextField txtmsex;
	
	

	@FXML
	void delete(ActionEvent event) {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setHeaderText("ȸ���� �����Ͻðڽ��ϱ�?");
		Optional<ButtonType> optional = alert.showAndWait();
		if (optional.get() == ButtonType.OK) {
			MemberDao.getMemberDao().delete(member.getM_no());
			Alert alert2 = new Alert(AlertType.INFORMATION);
			alert2.setHeaderText("�����Ǿ����ϴ�.");
			alert2.showAndWait();
			SystemController.getinstance().loadpage("a_member");
		}
	}

	public void membertableload() {
		ObservableList<Member> members = MemberDao.getMemberDao().memberlist();
		memberlist.setItems(members);
		TableColumn tc = memberlist.getColumns().get(0);
		tc.setCellValueFactory(new PropertyValueFactory<>("m_no"));
		tc = memberlist.getColumns().get(1);
		tc.setCellValueFactory(new PropertyValueFactory<>("m_id"));
		tc = memberlist.getColumns().get(2);
		tc.setCellValueFactory(new PropertyValueFactory<>("m_name"));
		tc = memberlist.getColumns().get(3);
		tc.setCellValueFactory(new PropertyValueFactory<>("m_sex"));
		tc = memberlist.getColumns().get(4);
		tc.setCellValueFactory(new PropertyValueFactory<>("m_phone"));
		tc = memberlist.getColumns().get(5);
		tc.setCellValueFactory(new PropertyValueFactory<>("m_email"));
		tc = memberlist.getColumns().get(6);
		tc.setCellValueFactory(new PropertyValueFactory<>("m_pw"));
		
		memberlist.setOnMouseClicked(e -> {
		
			if (e.getButton().equals(MouseButton.PRIMARY)) {
			
				member = memberlist.getSelectionModel().getSelectedItem();
			
				lblname.setText(member.getM_name());
				lblsex.setText(Integer.toString(member.getM_sex()));
				lblphone.setText(member.getM_phone());
				lblemail.setText(member.getM_email());
				lblpw.setText(member.getM_pw());
				
			}
		});
		

	}

	private static String mid;

	@FXML
	void update(ActionEvent event) {
		String mname = txtmname.getText();
		String mpw = txtmpw.getText();
		String memail = txtmemail.getText();
		String mphone = txtmphone.getText();
		int msex = Integer.parseInt(txtmsex.getText());
		Member member2 = new Member(member.getM_no(), mid, mname, msex, mphone, memail, mpw);

		boolean result = MemberDao.getMemberDao().update(member2);
		if (result) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setHeaderText("ȸ�� ���� �Ϸ�");
			alert.showAndWait();
			SystemController.getinstance().loadpage("a_member");

		}
	}

	@FXML
	void back(ActionEvent event) {
		SystemController.getinstance().loadpage("a_system");
	}

}

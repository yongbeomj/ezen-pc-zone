package Domain;

public class SalesDate {
	

	private String name;
	private int totalprice;
	

	
	public SalesDate() {
	
	}



	public SalesDate(String name, int totalprice) {
		this.name = name;
		this.totalprice = totalprice;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public int getTotalprice() {
		return totalprice;
	}



	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}

	
	
	
	
	
	
}

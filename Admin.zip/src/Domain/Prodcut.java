package Domain;

public class Prodcut {

}

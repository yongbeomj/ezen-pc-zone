package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Domain.Member;

public class MemberDao {
	private Connection connection; 
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	
	private static MemberDao memberDao = new MemberDao();
	public MemberDao() {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/javafx?serverTimeZonse=UTC", "root",
					"1234");
		} catch (Exception e) {
			System.err.println(" *DB���� ���� : " + e);
		}
	}
	
	
	
			
	
	
	
	
	

}

package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import Domain.ProductOrder;
import Domain.TimeOrder;

public class TimeOrderDao {

	private Connection connection; // DB ���� �������̽� ����
	private PreparedStatement preparedStatement; // SQL ���� �������̽� ����
	private ResultSet resultSet; // ����(�˻����) ���� �������̽� ����

	private static TimeOrderDao timeOrderDao = new TimeOrderDao();

	public TimeOrderDao() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/ezenpczone?serverTimeZonse=UTC",
					"root", "1234");
		} catch (Exception e) {
			System.err.println(" *DB���� ���� : " + e);
		}
	}

	public static TimeOrderDao getTimeOrderDao() {
		return timeOrderDao;
	}

	public int timeordercount() {
		String sql = "select to_price from timeorder";
		ArrayList<TimeOrder> toprices = new ArrayList<>();

		try {
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				toprices.add(new TimeOrder(resultSet.getInt(1)));
			}
			int price = 0;
			for (TimeOrder order : toprices) {
				price += order.getTo_price();
			}
			return price;
		} catch (Exception e) {
		}
		return 0; // DB ����

	}

	// �ð� �ϸ���
	public int timeorderdate1(String day) {

		String sql = "SELECT sum(to_price) FROM timeorder WHERE DATE_FORMAT(to_date, '%m-%d') BETWEEN ? AND ?";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, day);
			preparedStatement.setString(2, day);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				return resultSet.getInt(1);
			} else {
				return 0;
			}
		} catch (Exception e) {
		}
		return 0;

	}
	
	// �ð� ������
//	public int timeorderdate3(String year) {
//		String sql = "SELECT sum(to_price), to_date FROM timeorder WHERE DATE_FORMAT(to_date, '%Y') BETWEEN ? AND ?";
//		
//		try {
//			preparedStatement = connection.prepareStatement(sql);
//			preparedStatement.setString(1, year);
//			preparedStatement.setString(2, year);
//			resultSet = preparedStatement.executeQuery();
//			if (resultSet.next()) {
//				return resultSet.getInt(1);
//			} else {
//				return 0;
//			}
//		} catch (Exception e) {
//		}
//		return 0;
//
//	}

}

package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class MemberController {
	
    @FXML
    private Button btnback;
    
    @FXML
    private Button btndelete;

    @FXML
    private Button btnsearch;

    @FXML
    private Button btnupdate;

    @FXML
    private TableView<?> memberlist;

    @FXML
    private TextField txtmemail;

    @FXML
    private TextField txtmname;

    @FXML
    private TextField txtmphone;

    @FXML
    private TextField txtmpw;

    @FXML
    private TextField txtmsex;
    

    @FXML
    void back(ActionEvent event) {
    	SystemController.getinstance().loadpage("a_system");
    }

}

package Controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Dao.MemberDao;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;

public class SalesController implements Initializable {

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		//lbldayview.setText(MemberDao.getMemberDao().membercount() + "");
		lblmember.setText(MemberDao.getMemberDao().membercount() + "");
		//lbldppay.setText(MemberDao.getMemberDao().boardcount() + "");

	//	lbldayview.setAlignment(Pos.CENTER);
		lblmember.setAlignment(Pos.CENTER);
		//lbldppay.setAlignment(Pos.CENTER);

//		// ������Ʈ
//		ObservableList<Product> products = ProductDao.getProductDao().productlist();
//		
//		ObservableList<PieChart.Data> observableList = FXCollections.observableArrayList();
//		for(Product product : products) {
//			
//			observableList.add(new PieChart.Data(product.getActivation(), 1 ));
//		}
//
//		
//		pc.setData(observableList);
//		

//		// ����Ʈ
//		XYChart.Series series = new XYChart.Series<>(); // 1.�迭����
//		series.setName("��ǰ ��"); // 2.�迭�̸�
//		// DB ����[QUERY: select �˻���� ] : ����Ʈ�� ��ü �ϳ��� ������
//		ArrayList<ProductDate> productDates = ProductDao.getProductDao().productdatelist();
//		for (ProductDate productDate : productDates) {
//			// 3. �迭 �� �ֱ�
//			// 1. �� ����
//			XYChart.Data data = new XYChart.Data<>(productDate.getDate(), productDate.getCount());
//
//			// 2. �迭�� �� �ֱ�
//			series.getData().add(data);
//		}
//		// y�� ����
//		lc.getYAxis().setAutoRanging(false); // y�� �ڵ���������
//
//		lc.getData().add(series); // 4. �迭�� ��Ʈ�� �ֱ�
//
//		// ���̺� ���� ����
//		if (productDates.size() == 1) {
//			lblincrease.setText("����");
//		} else {
//
//			if (productDates.get(productDates.size() - 1).getCount() > productDates.get(productDates.size() - 2)
//					.getCount()) {
//				// ����Ʈ�� ������ ��ü�� ��¥�� �� > ����Ʈ�� ������ �� ��ü�� ��¥�� ��
//				lblincrease.setText("����");
//			} else if (productDates.get(productDates.size() - 1).getCount() == productDates.get(productDates.size() - 2)
//					.getCount()) {
//				lblincrease.setText("��������");
//			} else {
//				lblincrease.setText("����");
//			}
//		}
		
		
		
		
		

	}

	@FXML
	private Button btnback;

	@FXML
	private DatePicker ddp;

	@FXML
	private Label lblday;

	@FXML
	private Label lbldayview;

	@FXML
	private Label lbldppay;

	@FXML
	private Label lblmember;

	@FXML
	private Label lblmonth;

	@FXML
	private Label lblmpay;

	@FXML
	private Label lblmppay;

	@FXML
	private Label lblmtpay;

	@FXML
	private Label lblyear;

	@FXML
	private Label lblypay;

	@FXML
	private Label lblyppay;

	@FXML
	private Label lblytpay;

	@FXML
	private DatePicker mdp;

	@FXML
	private LineChart mlc;

	@FXML
	private PieChart pc;

	@FXML
	private DatePicker ydp;

	@FXML
	private LineChart ylc;

	@FXML
	void back(ActionEvent event) {
		SystemController.getinstance().loadpage("a_system");
	}

}

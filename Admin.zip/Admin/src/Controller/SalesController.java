package Controller;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Dao.MemberDao;
import Dao.ProductDao;
import Dao.ProductOrderDao;
import Dao.SalesDao;
import Dao.TimeOrderDao;

import Domain.SalesDate;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class SalesController implements Initializable {

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		lblmember.setText(MemberDao.getMemberDao().membercount() + "");
		

		lblmember.setAlignment(Pos.CENTER);
		lbldppay.setAlignment(Pos.CENTER);
		
//	ObservableList<SalesDate> abc = ProductOrderDao.getProductOrderDao().productorderdate3();
//		
//		System.out.println(abc.get(0).getTotalprice());
//		// ����Ʈ
//		XYChart.Series series = new XYChart.Series<>(); // 1.�迭����
//		series.setName("�Ѹ����"); // 2.�迭�̸�
//		// DB ����[QUERY: select �˻���� ] : ����Ʈ�� ��ü �ϳ��� ������
//		ArrayList<SalesDate> salesDates = SalesDao.getSalesDao().totalprice()
//		for (SalesDate salesDate : salesDates) {
//			// 3. �迭 �� �ֱ�
//			// 1. �� ����
//			XYChart.Data data = new XYChart.Data<>(salesDate.getName(), salesDate.getTotalprice());
//
//			// 2. �迭�� �� �ֱ�
//			series.getData().add(data);
//		}
//		// y�� ����
//		ylc.getYAxis().setAutoRanging(false); // y�� �ڵ���������
//		ylc.getData().add(series); // 4. �迭�� ��Ʈ�� �ֱ�


		
		
		

	}
	
	
    @FXML
    public void ddp(ActionEvent event) {
    	String date= ddp.getValue().toString();
    	String [] day =	date.split("-",2);
    	
    	ObservableList < PieChart.Data > totalprices = FXCollections.observableArrayList();
    	
    	int productprice = ProductOrderDao.getProductOrderDao().productorderdate1(day[1]);	// ��ǰ����
    	int timeprice = TimeOrderDao.getTimeOrderDao().timeorderdate1(day[1]);				// �ð�����
    	int totalprice2 = productprice+ timeprice;
    	PieChart.Data data = new PieChart.Data("��ǰ ����� : "+productprice, productprice );
    	PieChart.Data data2 = new PieChart.Data("�ð� ����� : "+timeprice, timeprice );
    	
    	totalprices.add(data);
    	totalprices.add(data2);
    	
    	lbldppay.setText(totalprice2+"");
    	pc.setData(totalprices);
    	
    }
    
//    @FXML
//    private TextField ydp;
//
//    @FXML
//    private Button btny_search;
//    
//    @FXML
//    void y_search(ActionEvent event) {
//    	String year = ydp.getText();
//    	int timeprice3= TimeOrderDao.getTimeOrderDao().timeorderdate3(year);
//    	int productprice3 = ProductOrderDao.getProductOrderDao().productorderdate3(year);
//    	int totalprice3 = productprice3 + timeprice3;
//    }
    
    
    
    
	
	@FXML
	private Button btnback;

	@FXML
	private DatePicker ddp;

	@FXML
	private Label lbldppay;

	@FXML
	private Label lblmember;

	@FXML
	private Label lblmonth;

	@FXML
	private Label lblmpay;

	@FXML
	private Label lblmppay;

	@FXML
	private Label lblmtpay;

	
	@FXML
	private TextField mdp;

	@FXML
	private LineChart mlc;

	@FXML
	private PieChart pc;

	@FXML
	private LineChart ylc;

	@FXML
	void back(ActionEvent event) {
		SystemController.getinstance().loadpage("a_system");
	}

}

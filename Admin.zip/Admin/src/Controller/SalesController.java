package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;

public class SalesController {
	@FXML
    private Button btnback;

    @FXML
    private DatePicker ddp;

    @FXML
    private Label lblday;

    @FXML
    private Label lbldayview;

    @FXML
    private Label lbldppay;

    @FXML
    private Label lblmember;

    @FXML
    private Label lblmonth;

    @FXML
    private Label lblmpay;

    @FXML
    private Label lblmppay;

    @FXML
    private Label lblmtpay;

    @FXML
    private Label lblyear;

    @FXML
    private Label lblypay;

    @FXML
    private Label lblyppay;

    @FXML
    private Label lblytpay;

    @FXML
    private DatePicker mdp;

    @FXML
    private LineChart<?, ?> mlc;

    @FXML
    private PieChart pc;

    @FXML
    private DatePicker ydp;

    @FXML
    private LineChart<?, ?> ylc;

  
	   
	    @FXML
	    void back(ActionEvent event) {
	    	SystemController.getinstance().loadpage("a_system");
	    }
	    

	    
	    
	    
	

}

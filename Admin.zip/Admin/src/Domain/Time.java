package Domain;

public class Time {

}

package Controller;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import Dao.MemberDao;
import Dao.ProductDao;
import Dao.ProductOrderDao;
import Domain.Product;
import Domain.ProductOrder;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;

public class ProductListController implements Initializable{
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		producttableload();
		productordertableload();
	}
	
	@FXML
    private Button btnactivation;

    @FXML
    private Button btnback;

    @FXML
    private Button btndelete;

    @FXML
    private Button btnregister;

    @FXML
    private Button btnupdate;

    @FXML
    private Label lblpcategory;

    @FXML
    private Label lblpcount;

    @FXML
    private Label lblpdate;

    @FXML
    private Label lblpname;

    @FXML
    private Label lblpprice;

    @FXML
    private TableView<ProductOrder> productorderlist;

    @FXML
    private ImageView pimg;

    @FXML
    private TableView<Product> productlist;

	
	@FXML
	void activation(ActionEvent event) {

		btnactivation.setText(product.getActivation()); // ���õ� ��ǰ�� ���°� ��ư �ؽ�Ʈ�� ǥ��
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("�˸�");
		alert.setContentText("���º���");
		alert.setHeaderText("���¸� �����Ͻðڽ��ϱ�?");
		alert.showAndWait();

		int pa = product.getP_activation();
		
		int ch = pa + 1; 
		if (ch > 2) {
			ch = 1;
		}
		
		if (ch == 1) { 
			ProductDao.getProductDao().activationupdate(1, product.getP_no()); 
			producttableload(); 
			btnactivation.setText("�Ǹ���"); 
		}
		
		if (ch == 2) { 
			ProductDao.getProductDao().activationupdate(2, product.getP_no()); 
			producttableload();
			btnactivation.setText("ǰ��"); 

		}
	}
	
	@FXML
	void delete(ActionEvent event) {
		
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setHeaderText("��ǰ�� �����Ͻðڽ��ϱ�?");
		Optional<ButtonType> optional = alert.showAndWait();
		if (optional.get() == ButtonType.OK) {
			ProductDao.getProductDao().delete(product.getP_no());
			Alert alert2 = new Alert(AlertType.INFORMATION);
			alert2.setHeaderText("�����Ǿ����ϴ�.");
			alert2.showAndWait();
			SystemController.getinstance().loadpage("a_productlist");
		}
		
	
	}
	public static Product product;
	
	
	public void producttableload() {
		ObservableList<Product> products = ProductDao.getProductDao().productlist();
		productlist.setItems(products);
		TableColumn tc = productlist.getColumns().get(0);
		tc.setCellValueFactory(new PropertyValueFactory<>("p_no"));
		tc = productlist.getColumns().get(1);
		tc.setCellValueFactory(new PropertyValueFactory<>("p_name"));
		tc = productlist.getColumns().get(2);
		tc.setCellValueFactory(new PropertyValueFactory<>("p_count"));
		tc = productlist.getColumns().get(3);
		tc.setCellValueFactory(new PropertyValueFactory<>("p_category"));
		tc = productlist.getColumns().get(4);
		tc.setCellValueFactory(new PropertyValueFactory<>("p_price"));
		tc = productlist.getColumns().get(5);
		tc.setCellValueFactory(new PropertyValueFactory<>("activation"));
		tc = productlist.getColumns().get(6);
		tc.setCellValueFactory(new PropertyValueFactory<>("p_date"));

		productlist.setOnMouseClicked(e -> {
			// 2. Ŭ�� �̺�Ʈ�� ���콺 Ŭ���� ������
			if (e.getButton().equals(MouseButton.PRIMARY)) {
				// 3. ���̺� �信�� Ŭ���� ���� ������[��ü]
				product = productlist.getSelectionModel().getSelectedItem();
				// 4. ���õ� ��ü�� �̹��� ��� ��������
				Image image = new Image(product.getP_img());
				pimg.setImage(image);
				// 5. �� ��
				lblpname.setText("��ǰ�� : " +product.getP_name());
				lblpcount.setText("��ǰ��� : " + String.format("%,d",product.getP_count()));
				lblpcategory.setText("��ǰ�з� : " +product.getP_category());
				lblpdate.setText("����� : " + product.getP_date().split(" ")[0]);
				lblpprice.setText("��ǰ���� : " + String.format("%,d", product.getP_price()));
				
				btnactivation.setText(product.getActivation());
			}
		});
	}

	public void productordertableload() {
		// 1. DB���� ��ǰ��� ��������
		ObservableList<ProductOrder> productorders = ProductOrderDao.getProductOrderDao().productorderlist();
		// 2. ��ǰ����� ���̺� �信 �־��ֱ�
		
		productorderlist.setItems(productorders);
		// 3. ���̺� �信 ���� �ϳ��� �����ͼ� ����Ʈ�� ��ü�� �ʵ�� ����
		TableColumn tc = productorderlist.getColumns().get(0);
		tc.setCellValueFactory(new PropertyValueFactory<>("p_no"));
		tc = productorderlist.getColumns().get(1);
		tc.setCellValueFactory(new PropertyValueFactory<>("po_no"));
		tc = productorderlist.getColumns().get(2);
		tc.setCellValueFactory(new PropertyValueFactory<>("po_date"));
		tc = productorderlist.getColumns().get(3);
		tc.setCellValueFactory(new PropertyValueFactory<>("po_contents"));
		tc = productorderlist.getColumns().get(4);
		tc.setCellValueFactory(new PropertyValueFactory<>("po_count"));
		tc = productorderlist.getColumns().get(5);
		tc.setCellValueFactory(new PropertyValueFactory<>("pc_no"));
		tc = productorderlist.getColumns().get(6);
		tc.setCellValueFactory(new PropertyValueFactory<>("m_id"));
		tc = productorderlist.getColumns().get(7);
		tc.setCellValueFactory(new PropertyValueFactory<>("po_price"));
		
	}	
	
    @FXML
    private Button btnorderdetail;
	
    @FXML
    void orderdetail(ActionEvent event) {
    	SystemController.getinstance().loadpage("a_orderdetail");
    }

	

	@FXML
	void back(ActionEvent event) {
		SystemController.getinstance().loadpage("a_system");
	}

	

	@FXML
	void register(ActionEvent event) {
		SystemController.getinstance().loadpage("a_productregister");
	}

	@FXML
	void update(ActionEvent event) {
		SystemController.getinstance().loadpage("a_productupdate");
	}

}

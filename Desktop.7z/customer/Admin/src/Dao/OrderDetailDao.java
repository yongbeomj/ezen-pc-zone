package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class OrderDetailDao {

	
	private Connection connection;
	private PreparedStatement preparedStatement; 
	private ResultSet resultSet; 
	
	
	public OrderDetailDao() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/ezenpczone?serverTimeZonse=UTC", "root",
					"1234");
		} catch (Exception e) {
			System.err.println(" *DB���� ���� : " + e);
		}
	}
	
	
	private static OrderDetailDao orderdetailDao = new OrderDetailDao();
	
	public static OrderDetailDao getOrderDetailDao() {
		return orderdetailDao;
	}
	
	
	
	
	
	
	
	
	
}

package Domain;

public class Sales {

}

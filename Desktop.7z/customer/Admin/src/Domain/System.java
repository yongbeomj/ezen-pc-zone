package Domain;

public class System {

}
